<?php 
 global $cits;
 ?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php bloginfo('description'); ?>">

   
    <link rel="icon" href="<?php echo $cits['favicon-uplod']['url']; ?>">

    
    <?php wp_head(); ?>
  </head>
  <body <?php body_class(); ?>>



    <!-- Start Headear Area -->
    <header class="header-top-area">
       <div class="container">
           <div class="row align-items-center">
               <div class="col-md-6 col-sm-6 d-none d-sm-block">

                <!-- top Search -->
                   <div class="top-search" >
                       <form action="POST">
                           <input type="search" name="search" placeholder="Search">
                           <button type="submit"><i class="fas fa-search"></i></button>
                       </form>
                   </div>
               </div>
               <div class="col-md-6 col-sm-6">

                    <!-- Top Right link -->
                   <div class="top-right-link">
                       <ul class="justify-content-center justify-content-sm-center">
                           <li><a href="<?php echo $cits['login_url']; ?>"><i class="far fa-user-circle"></i>Login</a></li>
                           <li><a href="<?php echo $cits['register_url']; ?>"><i class="fas fa-pencil-alt"></i>Register</a></li>
                       </ul>
                   </div>
               </div>
           </div>
       </div>
    </header>
    <!-- End Headear Area -->

    <!-- Start Headear Menu Area -->
    <header class="header-area" 

    style="background: <?php echo $cits['header-bg']['background-color']; ?>;">
        <div class="container">
            <div class="row align-items-center ">
                <div class="col-lg-3 col-md-12">
                    <!-- Logo Area -->
                    <div class="logo">
                        <a href="<?php bloginfo('home'); ?>">
                            <img src="<?php echo $cits['logo-uplod']['url']; ?>" alt="Logo">
                        </a>
                        <a href="#" class="nav-icon">
                            <i class="fas fa-bars"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-9 col-md-12">
                    <!-- Menu Area -->
                    <nav class="menu">
                        <?php wp_nav_menu(array(
                            'theme_location' => 'main-menu'
                        )); ?>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- End Headear Menu Area -->
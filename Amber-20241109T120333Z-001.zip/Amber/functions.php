<?php 
add_action('after_setup_theme','amber_theme_setup');
function amber_theme_setup(){
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');

	// REGISTER Main Menu
	register_nav_menus(array(
		'main-menu' => 'Main Menu'
	));
	// Sidebar Post Type
	register_post_type('slider',array(
		'labels' => array(
			'name' => 'Sliders',
			'add_new' => 'Add New Slide',
			'add_new_item' => 'Add New Slide'
		),
		'public' => true,
		'supports' => array('title'),
		'menu_icon' => 'dashicons-images-alt2'
	));

	// Works Post Type
	register_post_type('works',array(
		'labels' => array(
			'name' => 'Works',
			'add_new' => 'Add New Work',
			'add_new_item' => 'Add New work'
		),
		'public' => true,
		'supports' => array('title','editor','thumbnail'),
		'menu_icon' => 'dashicons-admin-multisite'
	));
	// Register Taxonomy
	register_taxonomy('work_category','works',array(
		'labels' => array(
			'name' => 'Works Category',
			'add_new' => 'Add New Category',
			'add_new_item' => 'Add New Category'
		),
		'hierarchical' => true,
	));

}

// Crieat Widget
class AMBER_WORKS_WIDGET extends WP_Widget{

	public function __construct(){
		parent::__construct('aw_works','Amber Works Widgets',array(
			'description' => 'Amber Latest Works Widgets'
		));
	}
	// dynamic korer janna ai form function lagba
	public function form($instance){
		?>

		<p>
			<label for="<?php echo $this->get_field_id('title');?>">Title:</label>
			<input type="text" class="widefat" name="<?php echo $this->get_field_name('title');?>" id="<?php echo $this->get_field_id('title');?>" value="<?php if(isset($instance['title'])){echo $instance['title'];} ?>">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('limit');?>">Limit:</label>
			<input type="number" class="widefat" name="<?php echo $this->get_field_name('limit');?>" id="<?php echo $this->get_field_id('limit');?>" value="<?php if(isset($instance['limit'])){echo $instance['limit'];} ?>">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('order');?>">Order By :</label>
			<select class="widefat" name="<?php echo $this->get_field_name('order');?>" id="<?php echo $this->get_field_id('order');?>">
				<?php if(isset($instance['order'])): ?>
				<option value="<?php echo $instance['order']; ?>" selected><?php echo $instance['order']; ?></option>
				<?php endif; ?>
				<option value="ASC">ASC</option>
				<option value="DESC">DESC</option>
			</select>
		</p>

		<?php

	}
	// Simple widget korer jonno ai function lagba
	public function widget($args,$instance){
		
		?>

			<?php

			$title = isset($instance['title']) ? $instance['title']: ''; 
			$limit = isset($instance['limit']) ? $instance['limit']: 10; 
			$order = isset($instance['order']) ? $instance['limit']: 'DESC'; 

			echo $args['before_widget'];
			echo $args['before_title'];
			echo $title;
			echo $args['after_title'];

			 ?>

	        <div class="right-work-cl4 owl-carousel owl-theme">
	            <?php 
	            $works = new WP_Query(array(
	                'post_type' => 'works',
	                'posts_per_page' => $limit,
	                'order'         => $order,
	            ));
	            while($works->have_posts()) : $works->the_post();
	             ?>
	            <div class="single-img-cl4">
	                <?php the_post_thumbnail(); ?>
	            </div>
	            <?php endwhile; ?>
	        </div>
	    <?php echo $args['after_widget']; ?>
		<?php 
	}
}
// Crieat Widget
class FOOTER_AMBER_WIDGET extends WP_Widget{
	public function __construct(){
		parent::__construct('af_about_widget','Amber Footer Widgets',array(
			'description' => 'Amber Footer Widget'
		));
	}

	public function form($mberinstance){
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title');?>">Title:</label>
			<input type="text" class="widefat" name="<?php echo $this->get_field_name('title');?>" id="<?php echo $this->get_field_id('title');?>" value="<?php if(isset($mberinstance['title'])){echo $mberinstance['title'];} ?>">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('address');?>">Address :</label>
			<input type="text" class="widefat" name="<?php echo $this->get_field_name('address');?>" id="<?php echo $this->get_field_id('address');?>" value="<?php if(isset($mberinstance['address'])){echo $mberinstance['address'];} ?>">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('phone');?>">Phone :</label>
			<input type="text" class="widefat" name="<?php echo $this->get_field_name('phone');?>" id="<?php echo $this->get_field_id('phone');?>" value="<?php if(isset($mberinstance['phone'])){echo $mberinstance['phone'];} ?>">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('email');?>">Email :</label>
			<input type="text" class="widefat" name="<?php echo $this->get_field_name('email');?>" id="<?php echo $this->get_field_id('email');?>" value="<?php if(isset($mberinstance['email'])){echo $mberinstance['email'];}else{echo"info@ambertheme.com";} ?>">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('map');?>">Google Map Code :</label>
			<textarea type="text" class="widefat" name="<?php echo $this->get_field_name('map');?>" id="<?php echo $this->get_field_id('map');?>"><?php if(isset($mberinstance['map'])){echo $mberinstance['map'];}else{echo '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3603.3941374722526!2d88.92074571460918!3d25.425083383790714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fca5f47b1e37d3%3A0xb26153f93c3b7136!2sCoder%20IT%20Solution%20-%20Madilahat!5e0!3m2!1sen!2sbd!4v1617095216841!5m2!1sen!2sbd" style="border:0;" loading="lazy"></iframe>';} ?></textarea>
		</p>



		<?php
	}

	public function widget($amber,$mberinstance){
		?>


		<?php
			$title = isset($mberinstance['title']) ? $mberinstance['title']: '';
			$address = isset($mberinstance['address']) ? $mberinstance['address']: '';
			$phone = isset($mberinstance['phone']) ? $mberinstance['phone']: '';
			$email = isset($mberinstance['email']) ? $mberinstance['email']: '';
			$map = isset($mberinstance['map']) ? $mberinstance['map']: '';

			echo $amber['before_widget'];
			echo $amber['before_title'];
			echo $title;
			echo $amber['after_title'];
		

		?>

	            <ul>
	                <li><a href="#">
	                    <i class="fas fa-map-marker-alt"></i>
	                    <span><b>Address : &nbsp;</b><?php echo $address; ?></span>
	                </a></li>
	                <li><a href="tel:+7998711503020">
	                    <i class="fas fa-phone-alt"></i>
	                    <span><b>Phone : &nbsp;</b><?php echo $phone; ?></span> 
	                </a></li>
	                <li><a href="mailto:info@ambertheme.com">
	                    <i class="fas fa-envelope"></i>
	                    <span><b>Email : &nbsp;</b><?php echo $email; ?></span>
	                </a></li>
	            </ul>

	            <div class="footer-map">
	                <?php echo $map; ?>
	            </div>
    	<?php echo $amber['after_widget']; ?>
		<?php
	}
}

// Register Widget
add_action('widgets_init','amber_post_widget');
function amber_post_widget(){
	register_widget('FOOTER_AMBER_WIDGET');
	// Footer Sidebar
	register_sidebar(array(
		'name'	=> 'Footer Sidebar',
		'id'	=> 'footer_sidebar',
		'before_widget' => '<div class="col-lg-3 col-md-6"><div class="footer-item footer-item-1">',
		'after_widget' => '</div></div>',
		'before_title' => '<h4>',
		'after_title' => '<h4>',
	));

	register_widget('AMBER_WORKS_WIDGET');
	// Single Blog Sidebar
	register_sidebar(array(
		'name'	=> 'Blog Sidebar',
		'id'	=> 'blog_sidebar',
		'before_widget' => '<div class="right-work-area-cl4 right-content-1">',
		'after_widget' => '</div>',
		'before_title' => '<h3>',
		'after_title' => '<h3>',
	));

	register_sidebar(array(
		'name'	=> 'footer Widgets left middle',
		'id'	=> 'footer_widgets_left_middle'
	));
	
	register_sidebar(array(
		'name'	=> 'footer Widgets right middle',
		'id'	=> 'footer_widgets_right_middle'
	));

	register_sidebar(array(
		'name'	=> 'footer Widgets right',
		'id'	=> 'footer_widgets_right'
	));
}

// Register CSS JS
add_action('wp_enqueue_scripts','amber_css_js');
function amber_css_js(){

	// CSS Files
	wp_register_style('normalize',get_template_directory_uri().'/assets/css/normalize.css');
	wp_register_style('bootstrap',get_template_directory_uri().'/assets/css/bootstrap.min.css');
	wp_register_style('fontawesome',get_template_directory_uri().'/assets/css/fontawesome.min.css');
	wp_register_style('owl-css',get_template_directory_uri().'/assets/css/owl.carousel.min.css');
	wp_register_style('owl-theme',get_template_directory_uri().'/assets/css/owl.theme.default.min.css');
	wp_register_style('asPieProgress',get_template_directory_uri().'/assets/css/asPieProgress.css');
	wp_register_style('magnific',get_template_directory_uri().'/assets/css/magnific-popup.css');
	wp_register_style('oxygen','https://fonts.googleapis.com/css2?family=Oxygen:wght@300;400;700&display=swap');
	wp_register_style('main-style',get_template_directory_uri().'/assets/css/style.css');
	wp_register_style('responsive',get_template_directory_uri().'/assets/css/responsive.css');
	// css
	wp_enqueue_style('normalize');
	wp_enqueue_style('bootstrap');
	wp_enqueue_style('fontawesome');
	wp_enqueue_style('owl-css');
	wp_enqueue_style('owl-theme');
	wp_enqueue_style('asPieProgress');
	wp_enqueue_style('magnific');
	wp_enqueue_style('oxygen');
	wp_enqueue_style('main-style');
	wp_enqueue_style('responsive');
	wp_enqueue_style('theme-style',get_stylesheet_uri());


	// JS Files
	wp_register_script('popper',get_template_directory_uri().'/assets/js/popper.min.js');
	wp_register_script('bootstrap',get_template_directory_uri().'/assets/js/bootstrap.min.js');
	wp_register_script('owl-cl',get_template_directory_uri().'/assets/js/owl.carousel.min.js');
	wp_register_script('asPieProgress',get_template_directory_uri().'/assets/js/jquery-asPieProgress.min.js');
	wp_register_script('magnific',get_template_directory_uri().'/assets/js/jquery.magnific-popup.min.js');
	wp_register_script('mixitup',get_template_directory_uri().'/assets/js/mixitup.min.js');
	wp_register_script('scripts',get_template_directory_uri().'/assets/js/scripts.js');
	// js
	wp_enqueue_script('jquery');
	wp_enqueue_script('popper');
	wp_enqueue_script('bootstrap');
	wp_enqueue_script('owl-cl');
	wp_enqueue_script('asPieProgress');
	wp_enqueue_script('magnific');
	wp_enqueue_script('mixitup');
	wp_enqueue_script('scripts');
}

// Crieat ShortCode
add_shortcode('amber_months','amber_postes');
function amber_postes($atts,$content){

	$shortcode_attributes = shortcode_atts(array(
		'title' => 'Testiong'
	),$atts);
	extract($shortcode_attributes);

	ob_start();
	?>

    <section class="months-area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h2><?php echo $title; ?></h2>
                        <p>New Lorem ipsum dolor sit amet, consectetur adipisicing, elit. Quasi amet iste dignissimos doloribus voluptate fugiat, est ab. Unde nisi doloremque illo ad laudantium, eaque, doloribus dignissimos illum, ex voluptates delectus.</p>
                    </div>
                    <div class="month text-center">
                        <a href="#" class="btn-sty-1">Buy Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

	<?php 
	$output = ob_get_clean();
	return $output;
}



// Redux
require_once('inc/Redux/redux-framework.php');
require_once('inc/Redux/sample/config.php');



 ?>
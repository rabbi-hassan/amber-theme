/**
 * This stub is needed since @wordpress/ajax isn't an actual npm package for testing.
 *
 * @see https://github.com/facebook/jest/issues/870
 */
module.exports = {}

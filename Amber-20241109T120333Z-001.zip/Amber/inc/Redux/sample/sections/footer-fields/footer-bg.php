<?php
/**
 * Redux Framework checkbox config.
 * For full documentation, please visit: http://devs.redux.io/
 *
 * @package Redux Framework
 */

defined( 'ABSPATH' ) || exit;

Redux::set_section(
	$opt_name,
	array(
		'title'            => 'Footer Background Options',
		'subsection'       => true,
		'customizer_width' => '450px',
		'fields'			=> array(
			array(
				'title'		=> 'Footer Background',
				'id'		=> 'footer-bg',
				'type'		=> 'background',
				'default'  => array(
			        'background-color' => '#1f2a32',
			        'background-repeat' => 'no-repeat',
			        'background-attachment' => 'scroll',
			        'background-position' => 'center center',
			        'background-clip' => 'border-box',
			        'background-origin' => 'inherit',
			        'background-size' => 'cover'
			    )
				
			),
		),
		
	)
);

<?php 
/**
 * Redux Framework checkbox config.
 * For full documentation, please visit: http://devs.redux.io/
 *
 * @package Redux Framework
 */

defined( 'ABSPATH' ) || exit;


Redux::set_section(
	$opt_name,
	array(
		'title'			=> 'Copy Right Text',
		'subsection'	=> true,
		'customizer_width' => '450px',
		'fields'		=> array(
			array(
				'title'		=> 'Copyright Text',
				'id'		=> 'copyright-text',
				'type'		=> 'editor',
				'default'	=> '<p>© 2021 Coder IT Solution. All rights reserved.</p>
								<p>Powered by WordPress.</p>'
			),
		),

	)



);









 ?>
<?php
/**
 * Redux Framework text config.
 * For full documentation, please visit: http://devs.redux.io/
 *
 * @package Redux Framework
 */

defined( 'ABSPATH' ) || exit;

Redux::set_section(
	$opt_name,
	array(
		'title'            =>'Header Url',
		'id'               => 'header-url',
		'subsection'       => true,
		'customizer_width' => '700px',
		'fields'           => array(
			array(
				'title'       => 'Login Url',
				'id'       => 'login_url',
				'type'     => 'text',
				'default'  => '#',
			),
			array(
				'title'       => 'Register Url',
				'id'       => 'register_url',
				'type'     => 'text',
				'default'  => '#',
			),
			
		),
	)
);

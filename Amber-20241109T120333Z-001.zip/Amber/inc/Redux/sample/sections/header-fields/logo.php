<?php
/**
 * Redux Framework checkbox config.
 * For full documentation, please visit: http://devs.redux.io/
 *
 * @package Redux Framework
 */

defined( 'ABSPATH' ) || exit;

Redux::set_section(
	$opt_name,
	array(
		'title'            => 'Logo',
		'subsection'       => true,
		'customizer_width' => '450px',
		'fields'			=> array(
			array(
				'title'		=> 'Logo Uplod',
				'id'		=> 'logo-uplod',
				'type'		=> 'media',
				'url'		=> false,
				'default'	=> array(
					'url'	=> get_template_directory_uri().'/assets/images/logo.png',
				),
				
			),
			array(
				'title'		=> 'Header Background',
				'id'		=> 'header-bg',
				'type'		=> 'background',
				'default'  => array(
			        'background-color' => '#ac0071',
			        'background-repeat' => 'no-repeat',
			        'background-attachment' => 'scroll',
			        'background-position' => 'center center',
			        'background-clip' => 'border-box',
			        'background-origin' => 'inherit',
			        'background-size' => 'cover'
			    )
				
			),
		),
		
	)
);

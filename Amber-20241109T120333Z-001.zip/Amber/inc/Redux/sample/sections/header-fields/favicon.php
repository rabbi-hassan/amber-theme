<?php
/**
 * Redux Framework password config.
 * For full documentation, please visit: http://devs.redux.io/
 *
 * @package Redux Framework
 */

defined( 'ABSPATH' ) || exit;

Redux::set_section(
	$opt_name,
	array(
		'title'      => 'Favicon',
		'id'         => 'favicon',
		'subsection' => true,
		'fields'     => array(
			array(
				'title'       => 'Favicon Uplod',
				'id'       => 'favicon-uplod',
				'type'     => 'media',
				'url'	   => false,
				'subtitle' => 'Uplode your Favicon',
				'default'	=> array(
					'url' => get_template_directory_uri().'/assets/images/favicon.png',
				),
			),
		),
	)
);

<?php get_header(); ?>
    <?php 
        while(have_posts()) : the_post();
        $url = wp_get_attachment_url(get_post_thumbnail_id());
     ?>

    <!-- Start Banner Area -->
    <section class="banner-Area2">
            <div class="single-banner-item2" style="background: url('<?php echo $url; ?>') no-repeat scroll 0 0 / cover;">
                <div class="container">
                    <div class="banner-title2">
                        <h1><?php the_title(); ?></h1>
                        <div class="row chang-dire">
                            <div class="col-lg-6 col-md-12">
                               <div class="banner-left-link2">
                                   <ul class="">
                                       <li><a href="#"><i class="far fa-user"></i>by <?php the_author(); ?></a></li>
                                       <li><a href="#"><i class="far fa-clock"></i><?php the_time('F j'); ?></a></li>
                                       <li><a href="#"><i class="fas fa-quote-left"></i><?php comments_popup_link('No Comment','1 comment','% comment') ?></a></li>
                                   </ul>
                               </div>
                            </div>
                            <div class="col-lg-6 col-md-12">
                                <div class="banner-right-link2">
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item breadcrumb-1"><a href="<?php bloginfo('home'); ?>">Home </a></li>
                                        <li class="breadcrumb-item"><a href="/blog">Blog</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <?php endwhile; ?>
    <!-- End Banner Area -->

     <!-- Start Work Area2 -->
    <section class="work-area2">
     <div class="container">
         <div class="row gx-5 gy-5 justify-content-md-center">
            <?php 
                while(have_posts()) : the_post();
            ?>
             <div class="col-lg-4 col-md-6">
                 <div class="single-works-area2">
                     <div class="thumbnail-img2">
                        <a href="<?php the_permalink(); ?>">
                            <?php the_post_thumbnail(); ?>
                        </a>
                     </div>
                     <div class="work-content2">
                         <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                         <p>
                            <?php echo wp_trim_words(get_the_content(),15,'....'); ?>
                         </p>
                         <ul>
                            <li><a href="<?php the_permalink(); ?>">Learn more</a></li>
                            <li><i class="fas fa-comments"></i>&nbsp;<?php comments_popup_link('No Comment','1 comment','% comment'); ?></li>
                         </ul>
                     </div>
                 </div>
             </div>
            <?php endwhile; ?>

         </div>
         <div class="row">
            <div class="col-md-12">
                <div class="nmbr2">
                    <?php the_posts_pagination(array(
                        'next_text' => '<i class="fas fa-chevron-right"></i>',
                        'prev_text' => '<i class="fas fa-chevron-left"></i>',
                        'sereen_reader_text' => 'Pagination'
                    )); ?>
                </div>
            </div>
         </div>
     </div>   
    </section>
    <!-- End work Area -->
<?php get_footer(); ?>
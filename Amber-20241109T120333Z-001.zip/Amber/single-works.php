<?php get_header(); ?>

    <?php while(have_posts()) : the_post(); 

        $url = wp_get_attachment_url(get_post_thumbnail_id());

        ?>
    <section class="banner-Area2">
            <div class="single-banner-item2"

            style="background: url('<?php echo $url; ?>')

             no-repeat scroll 0 0 / cover;">
                <div class="container">
                    <div class="banner-title2">
                        <h1><?php the_title(); ?></h1>
                        <div class="row chang-dire">
                            <div class="col-lg-6 col-md-12">
                               <div class="banner-left-link2"  data-aos="fade-right">
                                   <ul class="">
                                       <li><a href="<?php the_permalink() ?>"><i class="far fa-user"></i>by <?php the_author(); ?></a></li>
                                       <li><a href="#"><i class="far fa-clock"></i><?php the_time('F j') ?></a></li>
                                   </ul>
                               </div>
                            </div>
                            <div class="col-lg-6 col-md-12">
                                <div class="banner-right-link2" data-aos="fade-left">
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item breadcrumb-1"><a href="<?php bloginfo('home'); ?>">Home </a></li>
                                        <li class="breadcrumb-item"><a href="/works">Works</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    </section>
    <!-- End Banner Area -->

    <!-- Start Work Area -->
    <section class="work-area7">
        <div class="container">
            <div class="row gx-5">
                <div class="col-lg-9">
                    <div class="owl-crsl-area7">

                            <div class="myCarousul owl-carousel owl-theme">
                                <?php 
                                    if(have_rows('sliders')):
                                    while(have_rows('sliders')) : the_row();
                                 ?>
                                <div class="single-img7">
                                    <img src="<?php echo get_sub_field('slide_image'); ?>" alt="">
                                </div>
                                <?php endwhile; endif; ?>


                           
                                
                            </div>
                    </div>
                    
                </div>

                <div class="col-lg-3">
                     <div class="content-area7">

                            <!-- single content -->
                             <div class="single-content7">
                                <a class="a-heart" href="#"><i class="fas fa-heart"></i>257</a>
                                <h3>
                                    <?php 
                                    $cats = get_the_terms(get_the_id(),'work_category');
                                    foreach($cats as $cat): ?>
                                    <?php echo $cat->name; ?>
                                    <?php endforeach; ?>
                                </h3>
                               <?php the_content(); ?>

                                <h2>Work Feature</h2>

                                <form action="/action_page.php">
                                    <?php 
                                    if(have_rows('work_feature_check')):
                                        while(have_rows('work_feature_check')) : the_row();
                                     ?>
                                     <?php echo get_sub_field('feature_item'); ?>
                                 <?php endwhile; endif; ?>
                                </form>
                               
                                

                                <a href="#" class="btn-sty-buy">Buy Now</a>
                             </div>


                     </div>   
                </div>
            </div>
        </div>
    </section>
    <?php endwhile; ?>

<?php get_footer(); ?>
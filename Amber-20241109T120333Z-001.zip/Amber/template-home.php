<?php 
get_header();

// Template Name: Home Template


 ?>

    <!-- Start Banner Area -->
    <section class="banner-Area">
        <div class="banners owl-carousel owl-theme" >
            <?php 
            $sliders = new WP_Query(array(
                'post_type' => 'slider',
                'posts_per_page' => -1,
                'order'          => 'ASC'

            ));
            while($sliders->have_posts()) : $sliders->the_post(); ?>
            <div class="single-banner-item" style="background: url('<?php the_field('slide_image'); ?>') no-repeat scroll 0 0 / cover;">
                <div class="banner-text">
                    <h1><?php the_field('slider_title_1'); ?></h1>
                    <h1><?php the_field('slider_title_2'); ?></h1>
                    <div class="buttons">
                        <ul>
                            <li><a class="btn-sty-2" href="<?php the_field('Slider_btn_url_1'); ?>"><?php the_field('Slider_btn_text_1'); ?></a></li>
                            <li><a class="btn-sty-1" href="<?php the_field('Slider_btn_url_1'); ?>"><?php the_field('Slider_btn_text_2'); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </section>
    <!-- End Banner Area -->

    <!-- Start Months Area -->
    <section class="months-area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h2><?php the_field('m_title'); ?></h2>
                        <p><?php the_field('m_desc'); ?></p>
                    </div>
                    <div class="month text-center">
                        <a href="<?php the_field('m_btns_url'); ?>" class="btn-sty-1"><?php the_field('m_btns_text'); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Months Area -->


    <!-- Start Works Area -->
    <section class="works-area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h2><?php the_field('w_title'); ?></h2>
                        <p><?php the_field('w_desc'); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="works-items owl-carousel owl-theme">
                        
                        <?php 

                        $works = new WP_Query(array(
                            'post_type' => 'works',
                            'posts_per_page' => '6',
                        ));

                        while($works->have_posts()) : $works->the_post(); ?>

                        <div class="single-work">
                            <div class="work-img">
                                <?php the_post_thumbnail(); ?>
                            </div>
                            <div class="work-content">
                                <h3><?php the_title(); ?><span class="float-right"><i class="fas fa-heart"></i></span></h3>
                                <P>
                                    <?php
                                    $cats = get_the_terms(get_the_id(),'work_category');
                                    foreach($cats as $cat):
                                     ?>

                                    <a href="<?php $cat->slug; ?>"><?php echo $cat->name; ?></a>

                                    <?php endforeach; ?>
                                    <span class="float-right">257</span>
                                </P>
                            </div>

                            <div class="work-overly">
                                <ul>
                                    <li><a href="#"><i class="fas fa-heart"></i></a></li>
                                    <li><a class="work-popup" href="<?php the_field('popup_image'); ?>"><i class="fas fa-search-plus"></i></a></li>
                                    <li><a href="<?php the_permalink(); ?>"><i class="fas fa-link"></i></a></li>
                                </ul>
                            </div>
                        </div>

                        <?php endwhile; wp_reset_postdata(); ?>
                        

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Works Area -->

    <!-- Start  Hero Putchase Area -->
    <section class="hero-purchase-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="hero">
                            <h1><?php the_field('h_content'); ?></h1>
                            <a href="<?php the_field('h_btn_ull'); ?>" class="btn-sty-2"><?php the_field('h_btn_text'); ?> &nbsp;&nbsp; <i class="fas fa-chevron-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <!-- End Hero Purchase Area -->

    <!-- Start Feature Area -->
    <section class="feature-area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h2><?php the_field('s_f_title'); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row">


                <?php
                 if (have_rows('s_f_ctn')):
                 while(have_rows('s_f_ctn')) : the_row();
                  ?>
                    <div class="col-md-6">
                        <div class="single-feature">
                            <div class="feature-icon">
                                <i class="fas <?php the_sub_field('s_f_icon'); ?>"></i>
                            </div>
                            <div class="feature-content">
                                <h4><?php the_sub_field('s_f_icon_title'); ?></h4>
                                <p><?php the_sub_field('s_f_icon_desc'); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endwhile; endif; wp_reset_postdata(); ?>
                


            </div>
        </div> 
    </section>
    <!-- End Feature Area -->

    <!-- Start Testimonials Area -->
    <section class="testimonials-area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="testimonials owl-carousel owl-theme">
                        <?php 
                        if (have_rows('testimonials_item')):
                        while(have_rows('testimonials_item')) : the_row();
                        ?>

                        <div class="single-testimonial text-center">
                            <i class="fas fa-quote-right"></i>
                            <h1><?php the_sub_field('testimonials_text'); ?></h1>
                            <P><?php the_sub_field('testimonials_btm_text'); ?></P>
                        </div>

                        <?php endwhile; endif; wp_reset_postdata(); ?>

                    </div>
                </div>
            </div>
        </div>    
    </section>
    <!-- Start Testimonials Area -->

    <!-- Start Blog Area -->
    <section class="blog-area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h2>Latest Blog Posts</h2>
                    </div>
                </div>
            </div>
            <div class="row gx-5">

                <?php 
                $posts = new WP_Query(array(
                    'post_type' => 'post',
                    'posts_per_page' => 3,
                ));

                while($posts->have_posts()) : $posts->the_post();
                 ?>
                <div class="col-md-4">
                    <div class="single-blog-item">
                       <div class="thumbnail-img">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_post_thumbnail(); ?>
                            </a>
                       </div>
                       <div class="blog-content">
                           <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                           <p>
                               <?php echo wp_trim_words(get_the_content(),10,'....'); ?>
                           </p>
                           <ul>
                               <li><a href="<?php the_permalink(); ?>">Learn more</a></li>
                               <li><i class="fas fa-comments"></i><?php comments_popup_link('No Comment','1 comment','% comment'); ?></li>
                           </ul>                      
                       </div>
                    </div>
                </div>
                <?php endwhile; wp_reset_postdata(); ?>

            </div>
        </div>
    </section>
    <!-- End Blog Area -->

    <!-- Start Company Area -->
    <section class="company-area section-padding" style="background: <?php the_field('c_backgorund'); ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h2><?php the_field('company_title'); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row ex-row">

                <div class="col-md-4">
                    <div class="single-ex-item">
                        <div class="item-circle">
                            <div class="pie_progress" data-speed="90" role="progressbar" data-goal="80" data-barcolor="#FFF" data-barsize="5" aria-valuemin="0" aria-valuemax="100">
                                <div class="pie_progress__content">
                                      <i class="fas fa-cogs"></i>
                                </div>
                            </div>    
                        </div>
                        <div class="ex-item-content">
                            <h1><?php the_field('company_text_1'); ?></h1>
                            <p><?php the_field('company_desc_1'); ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single-ex-item">
                        <div class="item-circle">
                            <div class="pie_progress" data-speed="100" role="progressbar" data-goal="60" data-barcolor="#FFF" data-barsize="5" aria-valuemin="0" aria-valuemax="100">
                                <div class="pie_progress__content">
                                      <i class="fas fa-phone-alt"></i>
                                </div>
                            </div>    
                        </div>
                        <div class="ex-item-content">
                            <h1><?php the_field('company_text_2'); ?></h1>
                            <p><?php the_field('company_desc_2'); ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="single-ex-item">
                        <div class="item-circle">
                            <div class="pie_progress" data-speed="70" role="progressbar" data-goal="90" data-barcolor="#FFF" data-barsize="5" aria-valuemin="0" aria-valuemax="100">
                                <div class="pie_progress__content">
                                      <i class="fas fa-rocket"></i>
                                </div>
                            </div>    
                        </div>
                        <div class="ex-item-content">
                            <h1><?php the_field('company_text_3'); ?></h1>
                            <p><?php the_field('company_desc_3'); ?></p>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </section>
    <!-- End Company Area -->

    <!-- Start Team Area -->
    <section class="team-area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h2><?php the_field('our_team_title'); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row gx-5">

                <?php 
                    if(have_rows('our_team')):
                    while(have_rows('our_team')) : the_row();
                 ?>
                <div class="col-md-6 col-lg-3">
                    <div class="single-team">
                        <div class="team-img">
                            <img src="<?php the_sub_field('team_image'); ?>" alt="">
                        </div>                    
                        <div class="team-content">
                            <div class="team-name">
                                <h4><?php the_sub_field('team_name'); ?></h4>
                                <p><?php the_sub_field('team_character'); ?></p>
                            </div>
                            <p>
                                <?php
                                    echo wp_trim_words(get_sub_field('team_description'),10,'....');
                                ?>
                            </p>
                            <a class="btn-sty-1" href="<?php the_sub_field('team_btn_url'); ?>"><?php the_sub_field('team_btn_text'); ?></a>
                        </div>
                    </div>
                </div>
                <?php endwhile; endif; wp_reset_postdata(); ?>


            </div>
        </div>
    </section>
    <!-- End Team Area -->
<?php get_footer(); ?>
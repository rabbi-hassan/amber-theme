<?php get_header(); ?>
    <!-- Start Banner Area -->
    <?php 
        while(have_posts()) : the_post();
        $url = wp_get_attachment_url(get_post_thumbnail_id());
     ?>
    <section class="banner-Area2">
            <div class="single-banner-item2" style="background: url('<?php echo $url; ?>') no-repeat scroll 0 0 / cover;">
                <div class="container">
                    <div class="banner-title2">
                        <h1><?php the_title(); ?></h1>
                        <div class="row chang-dire">
                            <div class="col-lg-6 col-md-12">
                               <div class="banner-left-link2">
                                   <ul class="">
                                       <li><a href="#"><i class="far fa-user"></i>by <?php the_author(); ?></a></li>
                                       <li><a href="#"><i class="far fa-clock"></i><?php the_time('F j'); ?></a></li>
                                       <li><a href="#"><i class="fas fa-quote-left"></i><?php comments_popup_link('No Comment','1 comment','% comment') ?></a></li>
                                   </ul>
                               </div>
                            </div>
                            <div class="col-lg-6 col-md-12">
                                <div class="banner-right-link2">
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item breadcrumb-1"><a href="<?php bloginfo('home'); ?>">Home </a></li>
                                        <li class="breadcrumb-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <?php endwhile; ?>
    <!-- End Banner Area -->

    <!-- Start Work Area -->
    <section class="work-area4">

        <div class="container">
            <div class="row gx-5">
                <div class="col-lg-9">
                    <?php while(have_posts()) : the_post(); ?>
                    <div class="work-left-area4">
                        <div class="work-left-img4">
                            <?php the_post_thumbnail(); ?>
                        </div>
                        <div class="work-top-content4 work-middle-content4">
                            <?php the_content(); ?>
                        </div>
                    </div>
                    <?php endwhile; ?>
                    <div class="icon-area4">
                        <div class="icon-top-area4">            
                            <ul>
                                <li><a href="<?php the_permalink(); ?>"><i class="fas fa-tags"></i></a>Tags:</li>
                                <?php 
                                    $cats = get_the_terms(get_the_id(),'post_tag');
                                    if ($cats != false):
                                    foreach($cats as $cat) :
                                 ?>
                                <li><a href="#"><?php echo $cat->name; ?> , </a></li>
                                <?php endforeach; endif; ?>
                            </ul>
                        </div>

                        <div class="icon-footer-area4">
                            <h3>Related posts</h3>
                           <div class="key-area4">

                            <?php 
                            $post_id = get_the_id();
                            $category = get_the_category($post_id);
                            $catid = array();
                            foreach($category as $cat){
                                $catid[] = $cat->term_id;
                            }
                             ?>
                                <?php 

                                $related_post = new WP_Query(array(
                                    'post_type' => 'post',
                                    'posts_per_page' => 3,
                                    'category__in' => $catid,
                                    'post__not_in' => array($post_id)
                                ));
                                while($related_post->have_posts()) : $related_post->the_post();

                                 ?>
                                <div class="single-key4">
                                   <i class="fas fa-keyboard"></i>
                                   <p><?php the_time('F j'); ?></p>
                                   <p><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></p>  
                                </div>
                                <?php endwhile; ?>
                           </div>
                        </div>
                    </div>
                </div>

                <?php get_sidebar(); ?>
            </div>
        </div>

    </section>

    <!-- End Work Area -->



    <!-- Start form area -->
    <section class="form-area4">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="form-top-area4 right-content-1">
                        <h3>Add Comment</h3>
                        <div class="form_areases">
                            <?php echo do_shortcode('[contact-form-7 id="123" title="Contact form 1"]'); ?>
                        </div>
                    </div>
                    <div class="form-content-area4">
                        <?php 
                            // Comment Section
                            if ( comments_open() || get_comments_number() ) {
                                comments_template();
                            }


                         ?>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- End form area -->

    <?php $post_comments = fusion_get_page_option( 'blog_comments', $post->ID ); ?>
                <?php if ( ( Avada()->settings->get( 'blog_comments' ) && 'no' !== $post_comments ) || ( ! Avada()->settings->get( 'blog_comments' ) && 'yes' === $post_comments ) ) : ?>
                    <?php comments_template(); ?>
                <?php endif; ?>
    

<?php get_footer(); ?>
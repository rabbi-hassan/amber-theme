<div class="col-lg-3">
    <div class="right-top-area4">
        <?php dynamic_sidebar('blog_sidebar'); ?>
    </div>   
</div>
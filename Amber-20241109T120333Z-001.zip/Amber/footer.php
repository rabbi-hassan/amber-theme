<?php 
 global $cits;
 ?>
    <!-- Start Footer Area -->
    <footer class="footer-area" style="background: <?php echo $cits['footer-bg']['background-color']; ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="footer-colors">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>
            <div class="row gx-5">
                <?php dynamic_sidebar('footer_sidebar'); ?>


                    <div class="col-lg-3 col-md-6">
                        <?php dynamic_sidebar('footer_widgets_left_middle'); ?>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <?php dynamic_sidebar('footer_widgets_right_middle'); ?>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <?php dynamic_sidebar('footer_widgets_right'); ?> 
                    </div>
                


               

            </div>
            <div class="row mt-5">
                <div class="col-md-6">
                    <div class="copyright">
                        <?php echo $cits['copyright-text']; ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="back-top text-right">
                        <a href="#" class="btn-sty-1">back to top of page &nbsp; <i class="fas fa-angle-up"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer Area -->


    <?php wp_footer(); ?>
  </body>
</html>
<?php 
get_header();
// Template Name: Works Templte
 ?>

     
    <!-- Start Banner Area -->
    <section class="banner-Area5">
            <div class="single-banner-item5" style="background: url('<?php the_field('page_header_background'); ?>') no-repeat scroll 0 0 / cover;">
                <div class="container">
                    <div class="banner-title5">
                        <div class="row">
                            <div class="col-md-6">
                              <h1 data-aos="fade-right" ><?php the_title(); ?></h1>
                            </div>
                            <div class="col-md-6">
                                <div class="banner-right-link5">
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item breadcrumb-1"><a href="<?php bloginfo('home'); ?>">Home </a></li>
                                        <li class="breadcrumb-item"><a href="/works">works</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    </section>
    <!-- End Banner Area -->


     <!-- Start Work Area -->
    <section class="work-area5" >
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="work-title5">
                        <p><?php the_field('page_description'); ?></p>
                        <ul>
                            <li data-filter="all">View all :</li>

                            <?php 
                            $filters = get_terms('work_category');
                            foreach($filters as $filter) : 
                             ?>
                            <li data-filter=".<?php echo $filter->slug; ?>"><?php echo $filter->name; ?> , </li>
                            <?php endforeach; ?>

                        </ul>
                    </div>
                </div>
            </div>

            <div class="row gx-5 gy-5 justify-content-sm-center main-items">

                <?php 
                    $works = new WP_Query(array(
                        'post_type' => 'works',
                        'posts_per_page' => '6',
                    ));
                while($works->have_posts()) : $works->the_post();
                     ?>
                <div class="col-lg-4 col-md-6 mix <?php 
                    
                    $cats = get_the_terms(get_the_id(),'work_category');
                        foreach($cats as $cat):

                        echo $cat->slug." ";
                    
                                
                 ?>">
                    <!-- single work -->
                    <div class="single-work5">
                        <div class="work-img5">
                            <?php the_post_thumbnail(); ?>
                        </div>
                        <div class="work-content5">
                            <h3><?php the_title(); ?> <span class="float-right"><i class="fas fa-heart"></i></span></h3>
                            <P>
                                <?php foreach($cats as $cat): ?>
                                <a href="<?php $cat->slug; ?>"><?php echo $cat->name; ?></a>
                                <?php endforeach; ?>
                                    <span class="float-right">257</span>
                                </P>
                        </div>
                        <div class="work-overly5">
                            <ul>
                                <li><a href="#"><i class="fas fa-heart"></i></a></li>
                                <li><a class="work-popup" href="<?php the_field('popup_image'); ?>"><i class="fas fa-search-plus"></i></a></li>
                                <li><a href="<?php the_permalink(); ?>"><i class="fas fa-link"></i></a></li>
                            </ul>
                        </div>
                        
                    </div>  
                </div>

                <?php endforeach; endwhile; ?>
                
            </div>

        </div>
    </section>

    <!-- End work Area -->

  <?php get_footer(); ?>
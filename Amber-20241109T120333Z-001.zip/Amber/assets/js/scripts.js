
(function($){
$(document).ready(function(){


	

	$('.myCarousul,.owl-cst-content7').owlCarousel({
		items: 1,
		loop: true,
		nav: true,
		dots: false,
		navText:['<i class="fas fa-chevron-left"></i>','<i class="fas fa-chevron-right"></i>']
	});


	// Work - Carousel
	$('.right-work-cl4').owlCarousel({
		items:1,
		loop:true,
		dots:false,
		nav:true
	});





	// Mobile Menu
	$('.nav-icon').click(function(){
		$('.menu ul').slideToggle(1000);

		return false;
	});

	// Scroll Top
	$('.back-top a').click(function(){
		$('html,body').animate({
			scrollTop:0
		},2000);

		return false;
	});






	// Banner - Carousel
	$('.banners').owlCarousel({
		items:1,
		loop:true,
		dots:true,
		nav:false
	});

	// works-items - Carousel
	$('.works-items').owlCarousel({
		items:3,
		loop:true,
		dots:false,
		nav:true,
		margin:30,
		responsive:{
			0:{
				items:1
			},
			768:{
				items:3
			}
		}
	});

	// testimonials - Carousel
	$('.testimonials').owlCarousel({
		items:1,
		loop:true,
		dots:true,
		nav:false,
		autoplay:true
	});
	// Work Popup
	$('.work-popup').magnificPopup({
		type:'image',
		gallery:{
			enabled:true
		}
	});



	 $('.pie_progress').asPieProgress({
	    namespace: 'pie_progress'
	  });
	 $('.pie_progress').asPieProgress('start')







	 // 07_portfolio single area




	 // Owl carousel pic
	$(document).ready(function(){
	  $(".owl-csl7,.owl-cst-content7").owlCarousel({
	  	items:1,
	  	loop:true,
	  	nav:true,
	  	dots:false,
	  	navText:['<i class="fas fa-chevron-left"></i>','<i class="fas fa-chevron-right"></i>']

	  });
	});






        var mixer = mixitup('.main-items');


});
})(jQuery);